import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner datos= new Scanner(System.in);
        System.out.print("Introduce la base");
        int base= datos.nextInt();
        System.out.print("Introduce el exponente");
        int exponente= datos.nextInt();

        int total=base;

        for(int i=1; i<exponente; i++){
            total= total*base;
            System.out.print(total);

        }

    }
}