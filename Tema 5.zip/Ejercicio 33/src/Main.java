import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner datos= new Scanner(System.in);
        System.out.println("Introduce la altura de la U");
        int altura= datos.nextInt();

        for (int i = 1; i < altura; i++) {
            System.out.print("* ");
            for (int j = 2; j < altura; j++) {
                System.out.print("  ");
            }
            System.out.println("*");
        }

        System.out.print("  ");
        for (int i = 2; i < altura; i++) {
            System.out.print("* ");
        }
    }
}