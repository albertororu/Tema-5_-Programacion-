public class Main {
    public static void main(String[] args) {
        int i=320;
        while (i>160){
        i--;

            if (i%20==0)
            System.out.println (i);
        }
    }
}