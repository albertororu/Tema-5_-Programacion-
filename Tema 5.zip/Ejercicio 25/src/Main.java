import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner datos=new Scanner(System.in);
        System.out.println("Introduce un número");
        int numero= datos.nextInt();
        int dato= numero;
        int reves=0;

        while(numero>0){
            reves= (reves*10) + (numero % 10);
            numero /=10;
        }
        System.out.println("Si damos la vuelta al número obtenemos el " + reves);
    }
}