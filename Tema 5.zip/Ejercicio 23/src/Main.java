import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner datos= new Scanner(System.in);
        System.out.println("Introduzca un número");
        int numero= datos.nextInt();
        int suma=0;
        int contador=0;

        do{
            System.out.println("Introduce un numero");
            numero= datos.nextInt();
            suma+=numero;
            contador++;

         } while (suma<=10000);
        System.out.println("Ha introducido un total de " + contador + " numeros");
        System.out.println("La suma total es de " +suma);
        System.out.println("La media es " +suma/contador);
    }
}