import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner datos= new Scanner(System.in);
        System.out.println("Introduce un numero entero mayor que 1");
        int numero= datos.nextInt();
        int cuenta = 0;
        int suma = 0;

        for(int i=1; i< numero; i++){
            if( (i % 3)== 0){
                System.out.println(i +"");
                cuenta++;
                suma += i;
            }
        }
        System.out.println("Desde el 1 hasta el " + numero + " hay " + cuenta + " multiplos de 3 que suman " + suma);


    }
}