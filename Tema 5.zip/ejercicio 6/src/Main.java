public class Main {
    public static void main(String[] args) {
        int i = 320;
        do{
            i--;
            if (i%20 == 0)
                System.out.println(i);
        }
        while (i >120);

    }

}




