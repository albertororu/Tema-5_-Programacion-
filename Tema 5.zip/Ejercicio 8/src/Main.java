import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner datos= new Scanner (System.in);
        System.out.println("introduce el numero");
        int numero= datos.nextInt();
        for(int i=0; i<=10; i++){
            System.out.println(+i+"x"+numero+"="+ (i*numero));

        }



        
    }


    }
