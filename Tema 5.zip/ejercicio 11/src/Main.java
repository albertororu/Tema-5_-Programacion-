import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner datos = new Scanner(System.in);

        System.out.print("Introduce un numero");

        int numero = datos.nextInt();


        for (int i = numero + 1;  i <= numero + 5;  i++) {

            System.out.print(i + "las operaciones son" + "cuadrado=" +i*i + "cubo=" + i*i*i);

        }
    }
}