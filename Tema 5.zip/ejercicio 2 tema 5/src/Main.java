public class Main {
    public static void main(String[] args) {
        int i = 0;
        while (i < 100) {
            i++;
            if (i%5==0){
                System.out.println(i);
            }
        }
    }
}