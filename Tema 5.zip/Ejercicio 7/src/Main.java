import static java.lang.System.*;

public class Main {
    public static void main(String[] args) {
int intentos=4;
int numeroIntroducido;
boolean acertado= false;
do {
    System.out.println("introduzca la clave de la caja fuerte");
    numeroIntroducido = Integer.parseInt (System.console().readLine());
    if (numeroIntroducido == 8888) {
        acertado = true;
    } else {
        out.println("Clave incorrecta");
    }
    intentos--;
} while ((intentos>0)&& (!acertado));
if (acertado) {
    out.println("Ha abierto la caja fuerte");
} else {
    out.println("lo siento, ha agotado las 4 oportunidades.");
}

}


    }