import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner datos= new Scanner(System.in);
        System.out.println("Introduzca un numero entero positivo");
        long numero= datos.nextInt();

        long numero1 = numero;
        long volteado = 0;
        int longitud = 0;

        if (numero1 == 0) {
            longitud = 1;
        }

        while (numero1 > 0) {
            volteado = (volteado * 10) + (numero1 % 10);
            numero1 /= 10;
            longitud++;
        }
        System.out.print("Dígitos pares: ");

        int digito;
        int sumaPares = 0;

        for (int i = 0; i < longitud; i++) {

            digito = (int) (volteado % 10);

            if ((digito % 2) == 0) {
                System.out.print(digito + " ");
                sumaPares += digito;
            }
            volteado /= 10;
        }

        System.out.println(" Suma de los dígitos pares: " + sumaPares);
    }
}