import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

Scanner datos= new Scanner(System.in);
        System.out.println("Introduce la altura de la piramide");

        int altura= datos.nextInt();

        System.out.println("Introduce el caracter de relleno");
        int relleno= datos.nextInt();

        int planta=1;
        int longitud=1;
        int espacios=altura-1;
        while(planta<=altura){
            for(int i=1; i<=espacios; i++);{
                System.out.println("");
            }
            for(int i=1; i<=longitud;i++){
                System.out.println(relleno);
            }
            System.out.println();
        }

    }
}