import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner datos= new Scanner(System.in);
        System.out.println("Introduzca la altura de la L");
        int altura= datos.nextInt();

        for (int i = 1; i < altura; i++) {
            System.out.println("*");
        }

        for (int i = 0; i < altura / 2 + 1; i++) {
            System.out.print("* ");
        }

    }
}