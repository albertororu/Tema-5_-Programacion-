import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner datos= new Scanner(System.in);

        System.out.println("Introduce un numero1");

        int numero1= datos.nextInt();

        System.out.println("Introduce el numero 2");

        int numero2= datos.nextInt();

        while(numero1==numero2){
            System.out.println("Los numeros no pueden ser iguales");

            System.out.println("Introduce un numero1");

             numero1= datos.nextInt();

            System.out.println("Introduce el numero 2");

             numero2= datos.nextInt();
        }
        for(int i=numero1; i<=numero2;i++){
            if(i%7==0) {
                System.out.println(i);
            }

        }
    }
}