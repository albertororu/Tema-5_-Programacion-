import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner dato = new Scanner(System.in);
        System.out.println("Introduce un numero");
        int numero = dato.nextInt();

        int suma = 0;
        int unidades = 0;
        int maximo = 0;

        while (numero >= 0) {
            if (numero % 2 != 0) {
                unidades = unidades + 1;
                suma = suma + numero;
                System.out.println("Introduce un numero");
                numero = dato.nextInt();
                while (numero >= 0) {
                    if (numero % 2 != 0) {
                        unidades = unidades + 1;
                        suma = suma + numero;

                        System.out.println("Se ha introducido " + unidades + " numeros");
                        System.out.println("La media es  " + suma / unidades);

                    }
                    if (numero % 2 == 0) {
                        if (numero > maximo) {
                            maximo = numero;
                            System.out.println("El maximo es " + maximo);
                        } else System.out.println("El maximo es " + maximo);
                    }
                    System.out.println("Introduce un numero");
                    numero = dato.nextInt();

                }
            }
        }
    }
}