public class Main {
    public static void main(String[] args) {
       System.out.println("Introduzca un numero y le dire cuantos digitos tiene");
       long numeroIntroducido= Long.parseLong(System.console().readLine());
       long n= numeroIntroducido;
       int numerodeDigitos= 1;
       while(n > 10);
            {
            numerodeDigitos++;
            n/=10;
            }
        System.out.println(numeroIntroducido + " tiene " + numerodeDigitos + " digito/s.");
        }
}
