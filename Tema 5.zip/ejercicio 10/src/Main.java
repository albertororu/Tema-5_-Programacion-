import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
           Scanner datos= new Scanner(System.in);
        double suma=0;
        int contador=0;
           System.out.print("introduce un numero positivo");
           int numero= datos.nextInt();


        while(numero>=0){
            contador++;
            suma=suma+numero;
            System.out.print("la media es =" +suma/contador);
            System.out.print("Introduce un numero positivo");
                numero = datos.nextInt();
            }
        }
    }
