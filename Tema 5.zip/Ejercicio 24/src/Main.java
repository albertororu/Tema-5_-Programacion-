import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Introduce el número de niveles que tendrá la pirámide: ");
        int niveles = scanner.nextInt();

        int posiciones = niveles* 2 - 1;
        int posinicial = niveles;
        int posfinal = niveles;
        int contador = 1;


        for (int i = 0; i < niveles; i++) {
            contador=1;
            String resultado = "";

            for (int x = 0; x <= posiciones; x++) {
                if ((x < posinicial) || (x > posfinal)) {
                    resultado += " ";
                } else {
                    if (x < niveles) {
                        resultado += contador;
                        contador++;
                    } else {
                        resultado += contador;
                        contador--;
                    }
                }
            }
            System.out.println(resultado);
            posfinal++;
            posinicial--;
        }
    }
}