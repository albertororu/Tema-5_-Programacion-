import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner datos = new Scanner(System.in);
        System.out.print("Introduce una base");
        int base = datos.nextInt();
        System.out.print("Introduce un exponente");
        int exponente = datos.nextInt();

        int total = base;
        System.out.print(base);
        for (int i = 1; i < exponente; i++) {
            total=1;
            exponente=i;
            for (int j = 1; i < exponente; j++) {
                exponente*= base;
                System.out.print(total);
            }
        }
    }
}