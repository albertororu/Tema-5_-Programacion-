public class Main {
    public static void main(String[] args) {
        for (int i = 320; i >= 160; i--) {
            if (i % 20 == 0) {
                System.out.println(i);
            }
        }
    }
}