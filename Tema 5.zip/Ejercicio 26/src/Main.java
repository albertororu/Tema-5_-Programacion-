import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner datos= new Scanner(System.in);
        System.out.println("Introduce un número");
        long numero= datos.nextInt();
        System.out.println("Introduce un digito");
        int digito= datos.nextInt();

        System.out.print("Contando de izquierda a derecha el " + digito);
        System.out.println(" aparece dentro de " + numero);
        System.out.print("en las siguientes posiciones ");

        long numero1= numero;
        numero1= numero *10 + 1;

        long reves=0;
        int longitud=0;
        int posicion=1;

        if(numero==0){
            longitud = 1;
        } while (numero >0){
            reves = (reves *10) + (numero % 10);
            numero /=10;
            longitud++;
        } while (reves !=10){
            if ( (reves % 10)== digito){
                System.out.println(posicion + "");
            }
            reves /=10;
            posicion++;
        }

    }
}